package org.usfirst.frc.team3502.robot.commands.DriveClimb;

import edu.wpi.first.wpilibj.command.Command;

public class AutomaticClimber extends Command {

    public AutomaticClimber() {
    }

    protected void initialize() {
    }

    protected void execute() {
    }

    protected boolean isFinished() {
        return false;
    }

    protected void end() {
    }

    protected void interrupted() {
    }
}
