package org.usfirst.frc.team3502.robot.commands.Auton;

import org.usfirst.frc.team3502.robot.RobotMap;
import org.usfirst.frc.team3502.robot.commands.DriveClimb.DriveToGyroHeading;

import edu.wpi.first.wpilibj.Timer;

import edu.wpi.first.wpilibj.command.CommandGroup;

/**
 * Autonomous: 
 * Drive over the selected defense, shoot (drop) the ball, turn around
 * and go back over the same defense
 */
public class AutoDriveStraight extends CommandGroup {
	
	private static final Timer timer = new Timer();
	//private double driveTime, initialHeading;
    
    public  AutoDriveStraight() {
    	
    	//initialHeading = RobotMap.gyro.getAngle();
    	timer.start();
    	timer.reset();
    	
    	
    	/*
    	if (Math.abs(fwdThrottle) == 0.5)
    		driveTime = 4;  //Driving time when set to half throttle
    	if (Math.abs(fwdThrottle) == 1.0)
    		driveTime = 2;  //Driving time when set to full throttle
    	*/
    	//Drive over the selected defense
    	while(timer.get() <= 4) //Will need to test time
    		addSequential(new DriveToGyroHeading());
    	
    	//TODO: Add code to shoot/drop the ball
    	
    	//Turn 180 degrees
    	//Throttle argument is set to 0 so it doesn't drive forward while turning
    	addSequential(new DriveToGyroHeading());
    	
    	//Drive back over the defense in the opposite direction
    	timer.reset();
    	while(timer.get() <= 4)
    		addSequential(new DriveToGyroHeading());
    	
        // Add Commands here:
        // e.g. addSequential(new Command1());
        //      addSequential(new Command2());
        // these will run in order.

        // To run multiple commands at the same time,
        // use addParallel()
        // e.g. addParallel(new Command1());
        //      addSequential(new Command2());
        // Command1 and Command2 will run in parallel.

        // A command group will require all of the subsystems that each member
        // would require.
        // e.g. if Command1 requires chassis, and Command2 requires arm,
        // a CommandGroup containing them would require both the chassis and the
        // arm.
    }
}
